import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { apiBase } from './api';

// Contrato del backend (EnrollmentOut)
interface EnrollmentOut {
  userId: string;
  serviceId: string;
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  remainingSessions: number;
  startDate: string;
  endDate?: string;
}

interface Paged<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  number: number;
}

export interface BookingSummary {
    id: string;
    offeringId: string;
    offeringTitle: string;
    price: number;
    scheduledAt: string;
    status: string;
    active: boolean;
}

export type BookingSort = 'TITLE_ASC' | 'TITLE_DESC' | 'DATE_ASC' | 'DATE_DESC' | 'PRICE_ASC' | 'PRICE_DESC';
export type BookingActivityFilter = 'ALL' | 'ACTIVE' | 'INACTIVE';

export interface BookingPage {
    content: BookingSummary[];
    page: number;
    size: number;
    totalElements: number;
    totalPages: number;
}

@Injectable({ providedIn: 'root' })
export class BookingService {
    private readonly http = inject(HttpClient);

    /** GET /api/enrollments/me — MIS inscripciones (paginado en el backend). */
    listMine(page: number, size: number, sort: BookingSort, activity: BookingActivityFilter): Observable<BookingPage> {
        return this.http.get<Paged<EnrollmentOut>>(`${apiBase()}/enrollments/me`,
            { params: { page, size } }).pipe(
            map(p => ({
                content: p.content.map(e => ({
                    id: `${e.serviceId}:${e.userId}`,
                    offeringId: e.serviceId,
                    offeringTitle: '',   // el detalle se resuelve con getById(serviceId) si se necesita
                    price: 0,
                    scheduledAt: e.startDate,
                    status: e.status,
                    active: e.status === 'ACTIVE'
                })),
                page: p.number,
                size,
                totalElements: p.totalElements,
                totalPages: p.totalPages
            }))
        );
    }
}
