import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';
import { apiBase } from './api';

// Contrato del backend (OfferingOut)
interface ServiceOut {
  id: string; name: string; categoryId: string; price: number;
  detail?: string; shortDescription?: string; learningObjectives?: string; prerequisites?: string;
  capacity?: number; code: string; status: 'DRAFT' | 'ACTIVE' | 'INACTIVE';
  createdBy: string; createdAt: string; updatedAt: string;
}

interface CatalogItemOut {
  id: string; name: string; code: string; detail?: string;
  type: 'PREFERENCE' | 'CATEGORY'; status: 'ACTIVE' | 'INACTIVE';
}

export interface Offering {
  id: string;
  title: string;
  description: string;
  category: string;
  price: number;
  active: boolean;
  startTime?: string;
  endTime?: string;
  endDay?: string;
  photoUrl?: string;
}

export interface PageResult<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  number: number;
}

export interface CategoryCount {
  name: string;
  count: number;
}

// Adaptador API -> modelo del frontend (los componentes no cambian)
function toOffering(o: ServiceOut): Offering {
  return {
    id: o.id,
    title: o.name,
    description: o.shortDescription ?? o.detail ?? '',
    category: o.categoryId,
    price: o.price,
    active: o.status === 'ACTIVE'
  };
}

@Injectable({ providedIn: 'root' })
export class OfferingService {
  constructor(private http: HttpClient) {}

  // GET /api/services -> catálogo público paginado (solo ACTIVE con cupo)
  list() {
    return this.http.get<PageResult<ServiceOut>>(`${apiBase()}/services`)
      .pipe(map(p => p.content.map(toOffering)));
  }

  getById(id: string) {
    return this.http.get<ServiceOut>(`${apiBase()}/services/${id}`).pipe(map(toOffering));
  }

  // Categorías vienen del catálogo unificado
  getCategories() {
    return this.http.get<CatalogItemOut[]>(`${apiBase()}/catalog?type=CATEGORY`)
      .pipe(map(items => items.filter(i => i.status === 'ACTIVE').map(i => i.name)));
  }

  /** @deprecated el backend ya no expone top-categorías; se calcula del lado cliente */
  getTopCategories(limit: number = 8) {
    return this.getCategories().pipe(
      map(names => names.slice(0, limit).map(name => ({ name, count: 0 })))
    );
  }

  create(offering: Partial<Offering>) {
    return this.http.post<ServiceOut>(`${apiBase()}/provider/services`, this.toUpsert(offering))
      .pipe(map(toOffering));
  }

  update(id: string, updates: Partial<Offering>) {
    return this.http.put<ServiceOut>(`${apiBase()}/provider/services/${id}`, this.toUpsert(updates))
      .pipe(map(toOffering));
  }

  toggleStatus(id: string, active: boolean) {
    return this.http.patch<ServiceOut>(`${apiBase()}/provider/services/${id}/status`,
      { status: active ? 'ACTIVE' : 'INACTIVE' }).pipe(map(toOffering));
  }

  /** El backend devuelve la lista completa del proveedor (sin paginar). */
  listMyServices(page: number = 0, size: number = 10) {
    return this.http.get<ServiceOut[]>(`${apiBase()}/provider/services/me`).pipe(
      map(all => {
        const content = all.map(toOffering);
        return {
          content: content.slice(page * size, page * size + size),
          totalPages: Math.ceil(content.length / size),
          totalElements: content.length,
          number: page
        };
      })
    );
  }

  // El PUT del backend requiere el body completo válido; completamos defaults.
  private toUpsert(o: Partial<Offering>) {
    const title = o.title ?? 'Servicio';
    return {
      name: title,
      categoryId: o.category ?? '',
      price: o.price ?? 0,
      detail: o.description ?? '',
      shortDescription: o.description ?? '',
      learningObjectives: '',
      prerequisites: '',
      capacity: 10,
      code: (title.toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-|-$/g, '') || 'SRV')
             + '-' + Date.now().toString(36).toUpperCase()
    };
  }
}
